#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//int date=0, month=0, year=0;

struct Data{
	char name[255];
	char dob[255];
	int date;
	int month;
	int year;
	Data *next;
	Data *prev;
} *head=NULL, *tail=NULL;

Data *createData( char name[255], int date, int month, int year){
	Data *newData= (Data *)malloc(sizeof(Data));
	strcpy(newData->name, name);
	newData->date= date;
	newData->month=month;
	newData->year=year;
	newData->prev=NULL;
	newData->next=NULL;
	return newData;
}
void pushHead( char name[255], int date, int month, int year){
	Data *newData= createData( name, date, month, year);
	if(!head){
		head=tail=newData;
	}else{
		newData->next=head;
		head->prev=newData;
		head=newData;
	}
}
void pushTail( char name[255], int date, int month, int year){
	Data *newData= createData( name, date, month, year);
	if(!head){
		head=tail=newData;
	}else{
		tail->next=newData;
		newData->prev=tail;
		tail=newData;
	}
}

void pushMid(char name[255], int date, int month, int year){
	Data *newData= createData( name, date, month, year);
	if(!head){
		head=tail=newData;
	}else{
		if(head->year < year){
			pushHead(name, date, month, year);
		}else if(year < tail->year){
			pushTail(name, date, month, year);
		}else{
			Data *temp=head;
			if(temp->year== year){
				if( head->month > month){
					pushHead(name, date, month, year);
				}else if( month< tail->month){
					pushTail(name, date, month, year);
				}else if( temp->month== month){
					if(head->date > date){
						pushHead(name, date, month, year);
					}else if( date< tail->date){
						pushTail(name, date, month, year);
					}
				}else{
					while(month >= temp->month){
						temp=temp->next;
					}	
					temp->prev->next= newData;
					newData->prev= temp->prev;
					newData->next=temp;
					temp->prev=newData;
				}
			}
		}
	}
}

Data *popHead(){
	if(!head){
		return NULL;
	}else{
		Data *toBeDeleted= head;
		head= head->next;
		toBeDeleted->next=NULL;
		head->prev=NULL;
		free(head->prev);
		return toBeDeleted;
	}
}
char* convertMonth(int month){
	switch(month){
		case 1:
			return "january";
			break;
		case 2:
			return "february";
			break;
		case 3:
			return "march";
			
			break;
		case 4:
			return "april";
			break;
		case 5:
			return "may";
			break;
		case 6:
			return "june";
			break;
		case 7:
			return "july";
			break;
		case 8:
			return "august";
			break;
		case 9:
			return "september";
			break;
		case 10:
			return "october";
			break;
		case 11:
			return "november";
			break;
		case 12:
			return "december";
			break;
	}
}
void printAll(){
	if(!head){
		return;
	}else{
		Data *curr= head;
		while(curr){
			
			printf("%d %s %d - %s\n",curr->date, convertMonth(curr->month), curr->year, curr->name);
			curr=curr->next;
		}
	}
}

int sortDate(char dob[255]){

	int len=strlen(dob);
	int date=0, month=0, year=0;
	//date
	for(int i=0; i<len; i++){
		if(dob[i]==' '){
			if(i==2){
				date=10*(dob[0]-'0');
				date+=dob[i]-'0';
			}else{
				date=dob[0]-'0';
			}
		}
		break;
	}
	return date;
}
int sortMonth(char dob[255]){
	int len=strlen(dob);
	int month=0;
		//month
	char temp[20];
	int idx=0;
	for(int i=0; i<len; i++){
		if(dob[i]>='a' && dob[i]<='z'){
			temp[i]=dob[i];
			idx++;
		}
	}
	if(temp=="january"){
		month=1;
	}else if(temp=="february"){
		month=2;
	}else if(temp=="march"){
		month=3;
	}else if(temp=="april"){
		month=4;
	}else if(temp=="may"){
		month=5;
	}else if(temp=="june"){
		month=6;
	}else if(temp=="july"){
		month=7;
	}else if(temp=="august"){
		month=8;
	}else if(temp=="september"){
		month=9;
	}else if(temp=="october"){
		month=10;
	}else if(temp=="november"){
		month=11;
	}else if(temp=="december"){
		month=12;
	}
	return month;
}

int sortYear(char dob[255]){
	int len=strlen(dob);
	int year=0;
		//year
	year+=dob[len-1]-'0';
	year+=10*(dob[len-2]-'0');
	year+=100*(dob[len-3]-'0');
	year+=1000*(dob[len-4]-'0');
	return year;
}


int main(){
	
	int patient,cure;
	scanf("%d %d",&patient,&cure); getchar();
	getchar();
	char dob[255],name[255];
	
	for( int i=0; i<patient; i++){
		scanf("%[^-]-%[^\n]",dob, name);
		int date=sortDate(dob);
		int month=sortMonth(dob);
		int year=sortYear(dob);
		pushMid(name, date, month, year);
	}
	
//	for( int i=0; i<cure; i++){
//		popHead();
//	}
	if(patient-cure!=0){
		printf("Need %d more cure",patient-cure);
	}
	printAll();
	return 0;
}

//7 5
//2 august 1970 - Viriginasd Walter
//14 february 1980 - ronald rich
//18 december 1965 - Camrom
//30 july 1990 - Rosie Hawkins
//1 august 1970 - Yvonne
//28 january 1985 - ASfa Daly
//4 november 1991 - Lorcan Craig montes
